--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "GroceryInventory";
--
-- Name: GroceryInventory; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "GroceryInventory" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_Philippines.1252';


ALTER DATABASE "GroceryInventory" OWNER TO postgres;

\connect "GroceryInventory"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Categories" (
    "CategoryID" integer NOT NULL,
    "CategoryName" character varying NOT NULL
);


ALTER TABLE public."Categories" OWNER TO postgres;

--
-- Name: Categories_CategoryID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Categories" ALTER COLUMN "CategoryID" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Categories_CategoryID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Inventories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Inventories" (
    "InventoryID" integer NOT NULL,
    "StockQuantity" integer NOT NULL,
    "ReorderLevel" integer NOT NULL,
    "ReorderQuantity" integer NOT NULL,
    "UnitPrice" numeric NOT NULL,
    "DateReceived" date NOT NULL,
    "LastOrderDate" date NOT NULL,
    "ExpirationDate" date NOT NULL,
    "SalesVolume" integer NOT NULL,
    "InventoryTurnoverRate" integer NOT NULL,
    "Status" character varying NOT NULL,
    "ProductID" character varying(11) NOT NULL,
    "WarehouseID" integer NOT NULL
);


ALTER TABLE public."Inventories" OWNER TO postgres;

--
-- Name: Inventories_InventoryID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Inventories" ALTER COLUMN "InventoryID" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Inventories_InventoryID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Products" (
    "ProductID" character varying(11) NOT NULL,
    "ProductName" character varying NOT NULL,
    "CategoryID" integer NOT NULL,
    "SupplierID" character varying(11) NOT NULL
);


ALTER TABLE public."Products" OWNER TO postgres;

--
-- Name: Suppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Suppliers" (
    "SupplierID" character varying(11) NOT NULL,
    "SupplierName" character varying NOT NULL
);


ALTER TABLE public."Suppliers" OWNER TO postgres;

--
-- Name: Warehouses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Warehouses" (
    "WarehouseID" integer NOT NULL,
    "WarehouseName" character varying NOT NULL
);


ALTER TABLE public."Warehouses" OWNER TO postgres;

--
-- Name: Warehouses_WarehouseID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Warehouses" ALTER COLUMN "WarehouseID" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Warehouses_WarehouseID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: staging_raw; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staging_raw (
    "Product_ID" character varying,
    "Product_Name" character varying,
    "Catagory" character varying,
    "Supplier_ID" character varying,
    "Supplier_Name" character varying,
    "Stock_Quantity" integer,
    "Reorder_Level" integer,
    "Reorder_Quantity" integer,
    "Unit_Price" character varying,
    "Date_Received" date,
    "Last_Order_Date" date,
    "Expiration_Date" date,
    "Warehouse_Location" character varying,
    "Sales_Volume" integer,
    "Inventory_Turnover_Rate" integer,
    "Status" character varying
);


ALTER TABLE public.staging_raw OWNER TO postgres;

--
-- Data for Name: Categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Categories" ("CategoryID", "CategoryName") FROM stdin;
\.
COPY public."Categories" ("CategoryID", "CategoryName") FROM '$$PATH$$/4925.dat';

--
-- Data for Name: Inventories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Inventories" ("InventoryID", "StockQuantity", "ReorderLevel", "ReorderQuantity", "UnitPrice", "DateReceived", "LastOrderDate", "ExpirationDate", "SalesVolume", "InventoryTurnoverRate", "Status", "ProductID", "WarehouseID") FROM stdin;
\.
COPY public."Inventories" ("InventoryID", "StockQuantity", "ReorderLevel", "ReorderQuantity", "UnitPrice", "DateReceived", "LastOrderDate", "ExpirationDate", "SalesVolume", "InventoryTurnoverRate", "Status", "ProductID", "WarehouseID") FROM '$$PATH$$/4931.dat';

--
-- Data for Name: Products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Products" ("ProductID", "ProductName", "CategoryID", "SupplierID") FROM stdin;
\.
COPY public."Products" ("ProductID", "ProductName", "CategoryID", "SupplierID") FROM '$$PATH$$/4929.dat';

--
-- Data for Name: Suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Suppliers" ("SupplierID", "SupplierName") FROM stdin;
\.
COPY public."Suppliers" ("SupplierID", "SupplierName") FROM '$$PATH$$/4926.dat';

--
-- Data for Name: Warehouses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Warehouses" ("WarehouseID", "WarehouseName") FROM stdin;
\.
COPY public."Warehouses" ("WarehouseID", "WarehouseName") FROM '$$PATH$$/4928.dat';

--
-- Data for Name: staging_raw; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staging_raw ("Product_ID", "Product_Name", "Catagory", "Supplier_ID", "Supplier_Name", "Stock_Quantity", "Reorder_Level", "Reorder_Quantity", "Unit_Price", "Date_Received", "Last_Order_Date", "Expiration_Date", "Warehouse_Location", "Sales_Volume", "Inventory_Turnover_Rate", "Status") FROM stdin;
\.
COPY public.staging_raw ("Product_ID", "Product_Name", "Catagory", "Supplier_ID", "Supplier_Name", "Stock_Quantity", "Reorder_Level", "Reorder_Quantity", "Unit_Price", "Date_Received", "Last_Order_Date", "Expiration_Date", "Warehouse_Location", "Sales_Volume", "Inventory_Turnover_Rate", "Status") FROM '$$PATH$$/4923.dat';

--
-- Name: Categories_CategoryID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Categories_CategoryID_seq"', 7, true);


--
-- Name: Inventories_InventoryID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Inventories_InventoryID_seq"', 990, true);


--
-- Name: Warehouses_WarehouseID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Warehouses_WarehouseID_seq"', 990, true);


--
-- Name: Categories Categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Categories"
    ADD CONSTRAINT "Categories_pkey" PRIMARY KEY ("CategoryID");


--
-- Name: Inventories Inventories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Inventories"
    ADD CONSTRAINT "Inventories_pkey" PRIMARY KEY ("InventoryID");


--
-- Name: Products Products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Products"
    ADD CONSTRAINT "Products_pkey" PRIMARY KEY ("ProductID");


--
-- Name: Suppliers Suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Suppliers"
    ADD CONSTRAINT "Suppliers_pkey" PRIMARY KEY ("SupplierID");


--
-- Name: Warehouses Warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Warehouses"
    ADD CONSTRAINT "Warehouses_pkey" PRIMARY KEY ("WarehouseID");


--
-- Name: Inventories Inventories_ProductID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Inventories"
    ADD CONSTRAINT "Inventories_ProductID_fkey" FOREIGN KEY ("ProductID") REFERENCES public."Products"("ProductID");


--
-- Name: Inventories Inventories_WarehouseID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Inventories"
    ADD CONSTRAINT "Inventories_WarehouseID_fkey" FOREIGN KEY ("WarehouseID") REFERENCES public."Warehouses"("WarehouseID");


--
-- Name: Products Products_CategoryID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Products"
    ADD CONSTRAINT "Products_CategoryID_fkey" FOREIGN KEY ("CategoryID") REFERENCES public."Categories"("CategoryID");


--
-- Name: Products Products_SupplierID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Products"
    ADD CONSTRAINT "Products_SupplierID_fkey" FOREIGN KEY ("SupplierID") REFERENCES public."Suppliers"("SupplierID");


--
-- PostgreSQL database dump complete
--

